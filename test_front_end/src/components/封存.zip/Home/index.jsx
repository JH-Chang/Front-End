import React from "react";
import { Homepage } from "./home";

export function Home(props){
    return (<Homepage/>);
}