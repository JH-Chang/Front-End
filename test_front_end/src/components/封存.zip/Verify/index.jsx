import React from "react";
import { MyVerify } from "./verify";


export function Verify(props) {
    return (<MyVerify />);
}
