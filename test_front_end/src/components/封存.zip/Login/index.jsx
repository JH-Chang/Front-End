import React from "react";
import { OnboardingButton } from "./login";

export function MetaMask(props){
    return (<OnboardingButton/>);
}