import React from "react";
import { MyProfile } from "./profile";

export function Profile(props){
    return (<MyProfile/>);
}